# Interactive Heart Grid - Version 2

## Overview
This project is an interactive 8x8 grid of hearts that users can click to change colors. The hearts cycle between grey, red, green, and blue, and there is a reset button that resets all hearts to their default grey state.

### Key Features:
1. **8x8 Grid**: A grid consisting of 64 cells, each containing a heart.
2. **Four Quadrants**: The grid is visually divided into four quadrants for easy identification.
3. **Row Labels**: Each row is labeled on the left and right sides with numbers, making it easy to reference.
4. **Color Cycling**: Clicking on a heart cycles its color through grey, red, green, and blue.
5. **Reset Button**: Resets the entire grid to grey hearts.
6. **Live Count**: The count of each colored heart is displayed above the grid.

### Files:
- `index.html`: The HTML structure of the interactive heart grid.
- `styles.css`: The CSS styling for layout, quadrants, labels, and animations.
- `script.js`: The JavaScript file that provides interactivity, color cycling, and resetting functionality.

## How to Use:
1. **Click on Hearts**: Click on any heart in the grid to change its color.
2. **Reset the Grid**: Click the "Reset" button to set all hearts back to grey.
3. **Observe Counts**: The count of each heart color is displayed in real-time.

## Technologies Used:
- HTML
- CSS
- JavaScript

## Instructions to Run:
1. Download the zip file.
2. Extract the contents to a folder.
3. Open `index.html` in a web browser.

Enjoy interacting with the heart grid!
